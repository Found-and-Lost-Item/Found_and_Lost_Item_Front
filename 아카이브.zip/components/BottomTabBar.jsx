// import React from 'react';
// import { BottomTabBar } from '@react-navigation/bottom-tabs';
// import { View, Text } from 'react-native';

// export default function CustomBottomTabBar(props) {
//     return (
//     <BottomTabBar {...props} />
//     );
// }


