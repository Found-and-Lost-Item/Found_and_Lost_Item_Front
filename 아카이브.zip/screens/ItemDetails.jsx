import React from 'react';
import { View, Text } from 'react-native';

export default function ItemDetails() {
  return (
    <View>
      <Text>Item Details Screen</Text>
    </View>
  );
}
